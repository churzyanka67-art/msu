from datetime import UTC, datetime
from unittest.mock import AsyncMock

import pytest
from aiogram.exceptions import TelegramNetworkError
from aiogram.methods import EditMessageText
from aiogram.types import CallbackQuery, Chat, Message, User

from app.controller import Selection, make_screen
from app.handlers.flow import FlowHandlers
from app.storage import MemoryStore


def message(mid=1):
    return Message(
        message_id=mid,
        date=datetime.now(UTC),
        chat=Chat(id=7, type="private"),
        from_user=User(id=7, is_bot=False, first_name="A"),
    )


@pytest.mark.asyncio
async def test_state_commits_after_edit_and_cross_message_is_rejected():
    store = MemoryStore()
    first = make_screen("first", [[("next", ("reset", None))]], Selection())
    first.message_id = 1
    await store.set((7, 7), first)
    result = make_screen("second", [[("next", ("reset", None))]], Selection())
    controller = AsyncMock()
    controller.act.return_value = result
    bot = AsyncMock()
    handler = FlowHandlers(controller, store)
    query = CallbackQuery(
        id="q",
        from_user=message().from_user,
        chat_instance="x",
        message=message(),
        data=next(iter(first.actions)),
    )
    bot.edit_message_text.side_effect = TelegramNetworkError(
        method=EditMessageText(text="x"), message="offline"
    )
    await handler.callback(query, bot)
    assert await store.get((7, 7)) is first
    bot.edit_message_text.side_effect = None
    await handler.callback(query, bot)
    assert (await store.get((7, 7))).text == "second"
    query = query.model_copy(update={"message": message(2)})
    calls = controller.act.call_count
    await handler.callback(query, bot)
    assert controller.act.call_count == calls


@pytest.mark.asyncio
async def test_storage_user_isolation_expiry_and_start():
    store = MemoryStore(ttl=0)
    screen = make_screen("x", [], Selection())
    await store.set((7, 7), screen)
    assert await store.get((7, 7)) is None
    store = MemoryStore()
    ctrl = AsyncMock()
    ctrl.start.return_value = screen
    bot = AsyncMock()
    bot.send_message.return_value = message(5)
    await FlowHandlers(ctrl, store).start(message(), bot)
    assert (await store.get((7, 7))).message_id == 5
    assert await store.get((7, 8)) is None
