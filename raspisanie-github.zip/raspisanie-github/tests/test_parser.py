from datetime import date
from pathlib import Path

import pytest

from app.services.parser import SourceError, parse_options, parse_schedule

FIX = Path(__file__).parent / "fixtures"


def test_dynamic_options():
    assert [(x.id, x.name) for x in parse_options((FIX / "faculties.html").read_text(), "facultyid")] == [
        ("5", "Бакалавриат"),
        ("8", "Магистратура"),
        ("9", "Второе высшее образование"),
        ("10", "Аспирантура"),
    ]
    assert len(parse_options((FIX / "courses.html").read_text(), "course")) == 4
    assert parse_options((FIX / "groups.html").read_text(), "groupid")[0].name == "101гму"


def test_actual_day_and_custom_time():
    day = parse_schedule((FIX / "day.html").read_text(), date(2026, 9, 9))
    assert len(day.lessons) == 4
    assert day.lessons[0].subject == "История России"
    assert day.lessons[0].teacher == "Соловьев Константин Анатольевич"
    assert day.lessons[0].classroom == "В3"
    assert day.lessons[-1].start_time == "15:00"
    assert day.lessons[-1].end_time == "17:00"
    assert day.lessons[-1].teacher is None


def test_week_columns_and_empty_sunday():
    html = (FIX / "schedule.html").read_text()
    assert parse_schedule(html, date(2026, 9, 13)).lessons == []
    assert parse_schedule(html, date(2026, 9, 16)).lessons[0].subject == "История России"


@pytest.mark.parametrize("html", ["<html>Ошибка</html>", '<table id="timeTable"></table>'])
def test_malformed_is_not_empty(html):
    with pytest.raises(SourceError):
        parse_schedule(html, date(2026, 9, 9))


def test_closed_date_is_not_empty():
    with pytest.raises(SourceError):
        parse_schedule((FIX / "day.html").read_text(), date(2026, 9, 10))


def test_missing_options_is_error():
    with pytest.raises(SourceError):
        parse_options("<html/>", "facultyid")
