from datetime import date
from pathlib import Path
from urllib.parse import parse_qs

import httpx
import pytest

from app.services.msu_schedule import MsuScheduleService
from app.services.parser import SourceError

FIX = Path(__file__).parent / "fixtures"


def response_html(name):
    return (
        (FIX / f"{name}.html")
        .read_text()
        .replace("<form ", '<input name="_csrf-frontend" value="csrf-test"><form ', 1)
    )


@pytest.mark.asyncio
async def test_post_contract_cache_and_dates():
    calls = []

    def respond(req):
        calls.append(req)
        if req.method == "GET":
            return httpx.Response(
                200, text=response_html("faculties"), headers={"set-cookie": "session=abc; Path=/"}
            )
        data = parse_qs(req.content.decode())
        assert data["_csrf-frontend"] == ["csrf-test"]
        assert "session=abc" in req.headers["cookie"]
        if "TimeTableForm[groupId]" in data:
            assert data["TimeTableForm[dateStart]"] == ["09.09.2026"]
            assert data["TimeTableForm[dateEnd]"] == ["09.09.2026"]
            return httpx.Response(200, text=response_html("day"))
        return httpx.Response(
            200, text=response_html("groups" if "TimeTableForm[course]" in data else "courses")
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        service = MsuScheduleService(client)
        assert len(await service.get_faculties()) == 4
        assert len(await service.get_courses("5")) == 4
        assert len(await service.get_groups("5", "1")) == 9
        assert len((await service.get_schedule("1450", date(2026, 9, 9), "5", "1")).lessons) == 4
        before = len(calls)
        await service.get_faculties()
        await service.get_schedule("1450", date(2026, 9, 9), "5", "1")
        assert len(calls) == before
        await service.get_faculties(refresh=True)
        assert len(calls) > before


@pytest.mark.asyncio
@pytest.mark.parametrize("failure", ["timeout", "500", "403", "broken"])
async def test_source_failures(failure):
    def respond(req):
        if failure == "timeout":
            raise httpx.ReadTimeout("slow", request=req)
        return httpx.Response(int(failure) if failure.isdigit() else 200, text="not a form")

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        with pytest.raises(SourceError):
            await MsuScheduleService(client).get_faculties()


@pytest.mark.asyncio
async def test_cache_disabled():
    calls = []

    def respond(req):
        calls.append(req)
        return httpx.Response(200, text=response_html("faculties"))

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        s = MsuScheduleService(client, cache_enabled=False)
        await s.get_faculties()
        await s.get_faculties()
        assert len(calls) == 2


@pytest.mark.asyncio
async def test_expired_cache_refetches_and_rejected_group_errors():
    calls = []

    def respond(req):
        calls.append(req)
        return httpx.Response(200, text=response_html("faculties" if req.method == "GET" else "day"))

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        service = MsuScheduleService(client, catalog_ttl=0)
        await service.get_faculties()
        await service.get_faculties()
        assert len(calls) == 2
        with pytest.raises(SourceError, match="rejected"):
            await service.get_schedule("removed-id", date(2026, 9, 9), "5", "1")
