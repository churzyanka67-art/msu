from pathlib import Path
from urllib.parse import parse_qs

import httpx
import pytest

from app.services.msu_schedule import MsuScheduleService
from app.smoke import check_flow


@pytest.mark.asyncio
async def test_smoke_runs_real_components_without_telegram():
    def respond(req):
        data = parse_qs(req.content.decode()) if req.method == "POST" else {}
        name = (
            "schedule"
            if "TimeTableForm[groupId]" in data
            else "groups"
            if "TimeTableForm[course]" in data
            else "courses"
            if "TimeTableForm[facultyId]" in data
            else "faculties"
        )
        html = (Path(__file__).parent / f"fixtures/{name}.html").read_text()
        return httpx.Response(200, text='<input name="_csrf-frontend" value="test">' + html)

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        from datetime import date

        report = await check_flow(MsuScheduleService(client), today=lambda: date(2026, 9, 9))
        assert report["group"] == "101гму"
        assert report["days"] == ["2026-09-09", "2026-09-10", "2026-09-11", "2026-09-10"]
        assert report["reset"] is True
