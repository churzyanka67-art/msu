from datetime import UTC, date, datetime
from pathlib import Path

import httpx
import pytest

from app.controller import Controller, StaleCallback
from app.formatting import format_pages, shift_date, today_moscow
from app.models.schedule import DaySchedule, Lesson
from app.services.msu_schedule import MsuScheduleService


def test_format_escape_missing_and_long():
    pages = format_pages(DaySchedule(date(2026, 9, 9), [Lesson("09:00", "10:00", "<b>A & B</b>")]), "101")
    assert "&lt;b&gt;A &amp; B&lt;/b&gt;" in pages[0]
    assert "None" not in pages[0] and "👨" not in pages[0]
    assert "Среда, 9 сентября 2026" in pages[0]
    pages = format_pages(DaySchedule(date(2026, 9, 9), [Lesson("09:00", "10:00", "😀<&" * 4000)]), "101")
    assert len(pages) > 1
    assert all(len(p.encode("utf-16-le")) // 2 <= 4000 for p in pages)
    from bs4 import BeautifulSoup

    text = "".join(BeautifulSoup(p, "html.parser").get_text() for p in pages)
    assert text.count("😀") == 4000


def test_empty_and_date_boundaries():
    assert "занятий нет" in format_pages(DaySchedule(date(2026, 9, 13)), "101")[0]
    assert today_moscow(datetime(2026, 9, 9, 22, tzinfo=UTC)) == date(2026, 9, 10)
    assert shift_date(date(2026, 12, 31), 1) == date(2027, 1, 1)
    assert shift_date(date(2028, 3, 1), -1) == date(2028, 2, 29)


def callback(screen, label):
    return next(b.callback_data for row in screen.keyboard.inline_keyboard for b in row if label in b.text)


@pytest.mark.asyncio
async def test_selection_navigation_back_reset_and_stale():
    fix = Path(__file__).parent / "fixtures"

    def respond(req):
        from urllib.parse import parse_qs

        data = parse_qs(req.content.decode()) if req.method == "POST" else {}
        name = "faculties"
        if "TimeTableForm[facultyId]" in data:
            name = "courses"
        if "TimeTableForm[course]" in data:
            name = "groups"
        if "TimeTableForm[groupId]" in data:
            name = "schedule"
        html = (fix / f"{name}.html").read_text()
        return httpx.Response(200, text='<input name="_csrf-frontend" value="test">' + html)

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        ctrl = Controller(MsuScheduleService(client), today=lambda: date(2026, 9, 9))
        first = await ctrl.start()
        courses = await ctrl.act(first, callback(first, "Бакалавриат"))
        groups = await ctrl.act(courses, callback(courses, "1 курс"))
        day = await ctrl.act(groups, callback(groups, "101гму"))
        assert "История России" in day.text
        tomorrow = await ctrl.act(day, callback(day, "Завтра"))
        assert "10 сентября" in tomorrow.text
        after = await ctrl.act(tomorrow, callback(tomorrow, "Пятница"))
        assert "11 сентября" in after.text
        back = await ctrl.act(after, callback(after, "Четверг"))
        assert "10 сентября" in back.text
        reset = await ctrl.act(back, callback(back, "Сменить группу"))
        assert "Выберите факультет" in reset.text
        with pytest.raises(StaleCallback):
            await ctrl.act(reset, callback(first, "Бакалавриат"))
        with pytest.raises(StaleCallback):
            await ctrl.act(reset, "garbage")
        other = await ctrl.start()
        with pytest.raises(StaleCallback):
            await ctrl.act(other, callback(reset, "Бакалавриат"))
        assert all(len(b.callback_data.encode()) <= 64 for row in day.keyboard.inline_keyboard for b in row)


@pytest.mark.asyncio
async def test_network_error_can_retry_start():
    fail = True

    def respond(req):
        if fail:
            return httpx.Response(503)
        return httpx.Response(200, text=(Path(__file__).parent / "fixtures/faculties.html").read_text())

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        ctrl = Controller(MsuScheduleService(client))
        screen = await ctrl.start()
        assert "Не удалось" in screen.text
        fail = False
        screen = await ctrl.act(screen, callback(screen, "Повторить"))
        assert "Выберите факультет" in screen.text


@pytest.mark.asyncio
async def test_catalog_pages_and_back_preserve_selection():
    from unittest.mock import AsyncMock

    from app.models.schedule import Option

    service = AsyncMock()
    service.get_faculties.return_value = [Option(str(i), f"Факультет {i}") for i in range(25)]
    service.get_courses.return_value = [Option("1", "1")]
    service.get_groups.return_value = [Option("7", "Группа 7")]
    ctrl = Controller(service)
    screen = await ctrl.start()
    screen = await ctrl.act(screen, callback(screen, "Страница →"))
    assert any("Факультет 24" == b.text for row in screen.keyboard.inline_keyboard for b in row)
    screen = await ctrl.act(screen, callback(screen, "Факультет 24"))
    screen = await ctrl.act(screen, callback(screen, "1 курс"))
    screen = await ctrl.act(screen, callback(screen, "Назад"))
    assert screen.selection.faculty.id == "24"
    assert "Выберите курс" in screen.text
    screen = await ctrl.act(screen, callback(screen, "Назад"))
    assert "Выберите факультет" in screen.text


@pytest.mark.asyncio
async def test_retry_preserves_failed_date_and_long_schedule_pages():
    from unittest.mock import AsyncMock

    from app.controller import Selection
    from app.models.schedule import Option
    from app.services.parser import SourceError

    service = AsyncMock()
    service.get_schedule.return_value = DaySchedule(
        date(2026, 9, 9), [Lesson("09:00", "10:00", "Предмет " * 700)]
    )
    ctrl = Controller(service, today=lambda: date(2026, 9, 9))
    screen = await ctrl._render(
        Selection(Option("5", "Б"), Option("1", "1"), Option("7", "Группа"), date(2026, 9, 9), "schedule")
    )
    second = await ctrl.act(screen, callback(screen, "Страница →"))
    assert "Страница 2/" in second.text
    service.get_schedule.side_effect = SourceError("offline")
    error = await ctrl.act(second, callback(second, "Завтра"))
    assert error.selection.day == date(2026, 9, 9)
    service.get_schedule.side_effect = None
    service.get_schedule.return_value = DaySchedule(date(2026, 9, 10))
    recovered = await ctrl.act(error, callback(error, "Повторить"))
    assert recovered.selection.day == date(2026, 9, 10)
    assert "занятий нет" in recovered.text
    service.get_schedule.assert_awaited_with("7", date(2026, 9, 10), "5", "1", refresh=True)
